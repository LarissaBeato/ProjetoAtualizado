<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../projeto/CSSprojeto/curso1.css">
    <title>Cursos</title>
</head>
<body>
    <header>
    <a href="../projeto/pagInicial.php"><i class='bx bxs-home'></i></a>
    <div id="cursos">
    <h1>CURSOS</h1>
    </div>
    </header>

   
    <div class="retangulos">
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 1" />
            <p><b>NOME DO CURSO:</b></p>
            <p><b>CARGA HORÁRIA:</b></p>
            <p><b>INSTITUIÇÃO:</b></p>
            <p><b>PREÇO:</b></p>
            <p><b>MATRIZ CURRICULAR:</b></p>
            <button class="botao" href="link-curso">Comece aqui!</button>
</div>

<footer>
    <div class="icone2">
        <a href="cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
    </div>
    <div class="icone">
        <a href="perfil.php"><i class='bx bxs-user'></i></a>
    </div>
</footer>
    
</body>
</html>