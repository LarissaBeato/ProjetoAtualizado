<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['id_user'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

include_once("connect/connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$sql = "SELECT C.nomeCompleto, P.descricao, P.cursosExperiencia, P.id_perfil, C.email, P.curriculo_url
        FROM Perfil P
        INNER JOIN Cadastro C ON P.user_idfk = C.id_user
        WHERE P.user_idfk = :id_user";

$executado = $resultado->prepare($sql);
$executado->bindParam(':id_user', $_SESSION['id_user'], PDO::PARAM_INT);
$executado->execute();
$linhas = $executado->fetch(PDO::FETCH_ASSOC);
?>

<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/perfil.css">
    <title>LearnLab</title>
</head>

<body>
    <header class="menu">
        <a href="pagInicial.php"><i class='bx bxs-home'></i></a>
        <h1 class="classe">PERFIL</h1>
    </header>

    <div class="perfil">
        <i class='perfil bx bxs-user-circle'></i>
    </div>

    <div class="fundo_perfil">
        <form action="perfil.php" method="post" enctype="multipart/form-data">
            <input readonly type="hidden" name="idPerfil" id="id_perfil" value="<?php echo $linhas["id_perfil"]; ?>">
            <input readonly type="text" name="nomePerfil" id="nome_perfil" value="<?php echo $linhas["nomecompleto"]; ?>">
            <input readonly type="text" name="redesSociais" id="Redes_Sociais" value="<?php echo $linhas["email"]; ?>">
            <input type="text" name="descricao" id="descricao_perfil" placeholder="Adicione uma breve descrição" value="<?php echo $linhas["descricao"]; ?>">
            <textarea name="cursos" id="cursos" placeholder="Adicione caso possua Cursos e/ou Experiência"><?php echo $linhas["cursosexperiencia"]; ?></textarea>
            <input type="file" name="arquivo" accept="application/pdf">

            <!-- Exibir link para o currículo caso exista -->
            <?php if (!empty($linhas["curriculo_url"])): ?>
                <p><strong>Currículo:</strong> <a target="_blank" href="<?php echo $linhas["curriculo_url"]; ?>">Visualizar PDF</a></p>
            <?php endif; ?>

            
            <button id="btn-adiciona" type="submit" name="adiciona">Alterar Informações</button>
        </form>
    </div>

    <footer>
        <div class="icone2">
            <a href="cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
        </div>
        <div class="icone">
            <a href="logoff.php"><i class='bx bxs-exit'></i></a>
        </div>
    </footer>
</body>
</html>

<?php
if (isset($_POST["adiciona"])) {
    $descricao = $_POST["descricao"];
    $cursos = $_POST["cursos"];
    $id_perfil = $_POST['idPerfil'];

    // Atualizar os dados do perfil
    $sql = "UPDATE Perfil SET descricao = :descricao, cursosExperiencia = :cursos WHERE id_perfil = :id_perfil";
    $queryUpdate = $resultado->prepare($sql);
    $queryUpdate->bindParam(':descricao', $descricao);
    $queryUpdate->bindParam(':cursos', $cursos);
    $queryUpdate->bindParam(':id_perfil', $id_perfil);

    if (!$queryUpdate->execute()) {
        echo "<script>alert('Erro ao atualizar informações.');</script>";
    }

    // Verifica se um arquivo foi enviado
    if (!empty($_FILES['arquivo']['name'])) {
        $arquivo_tmp = $_FILES['arquivo']['tmp_name'];
        $extensao = strtolower(pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION));

        if ($extensao == 'pdf') {
            $novo_nome = SHA1($_SESSION['id_user'] . time()) . '.pdf';
            $destino = 'curriculos_perfil/' . $novo_nome;

            if (move_uploaded_file($arquivo_tmp, $destino)) {
                // Atualizar a URL do currículo no banco de dados
                $sql = "UPDATE Perfil SET curriculo_url = :curriculo_url WHERE id_perfil = :id_perfil";
                $queryCurriculo = $resultado->prepare($sql);
                $queryCurriculo->bindParam(':curriculo_url', $destino);
                $queryCurriculo->bindParam(':id_perfil', $id_perfil);

                if ($queryCurriculo->execute()) {
                    echo "<script>alert('Currículo atualizado com sucesso!');</script>";
                } else {
                    echo "<script>alert('Erro ao salvar o currículo no banco.');</script>";
                }
            } else {
                echo "<script>alert('Erro ao enviar o arquivo.');</script>";
            }
        } else {
            echo "<script>alert('Somente arquivos PDF são permitidos.');</script>";
        }
    }

    echo "<script>window.location.href = 'perfil.php';</script>";
}
?>
