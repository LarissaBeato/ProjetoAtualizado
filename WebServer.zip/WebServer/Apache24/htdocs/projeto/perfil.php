<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['id_user'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

include_once("connect/connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$sql = "SELECT C.nomeCompleto, P.descricao, P.cursosExperiencia, P.id_perfil, C.email
                FROM Perfil P
                INNER JOIN Cadastro C ON P.user_idfk = C.id_user
                WHERE P.user_idfk = " . $_SESSION['id_user'] . ";";
$indice = 0;

$executado = $resultado->prepare($sql);

if ($executado->execute()) {
    while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
        $linhas[$indice] = $linha;
        $indice++;
    }
}
?>

<html lang="PT-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/perfil.css">
    <title>LearnLab</title>
</head>

<body>
    <header class="menu">
        <a href="pagInicial.php"><i class='bx bxs-home'></i></a>
        <h1 class="classe">PERFIL</h1>
    </header>

    <div class="perfil">
        <i class='perfil bx bxs-user-circle'></i>
    </div>

    <div class="fundo_perfil">
        <form action="perfil.php" method="post">
            <input readonly type="hidden" name="idPerfil" id="id_perfil" placeholder="Nome Completo" value="<?php echo $linhas[0]["id_perfil"]; ?>">
            <input readonly type="text" name="nomePerfil" id="nome_perfil" placeholder="Nome Completo" value="<?php echo $linhas[0]["nomecompleto"]; ?>">

            <input readonly type="text" name="redesSociais" id="Redes_Sociais" placeholder="Redes Sociais" value="<?php echo $linhas[0]["email"]; ?>">

            <input type="text" name="descricao" id="descricao_perfil" placeholder="Adicione uma breve descrição" value="<?php echo $linhas[0]["descricao"]; ?>">

            <textarea name="cursos" id="cursos" placeholder="Adicione caso possua Cursos e/ou Experiência"><?php echo $linhas[0]["cursosexperiencia"]; ?></textarea>

            <!-- Remover o link de currículo se não for necessário -->
            <!-- <a target="blank" href="<?php echo $linhas[0]['curriculo_url']; ?>">Currículo</a> -->

            <button id="btn-adiciona" type="submit" name="adiciona">Alterar Informações</button>

            <a href="cadastroPerfil.php"><button id="btn-adiciona" type="button" name="adiciona">Termine seu Perfil</button></a>
        </form>
    </div>
  
    <footer>
    <div class ="icone2">
        <a href="cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
    </div>

        <div class ="icone">
            <a href= "logoff.php"><i class='bx bxs-exit'></i></a>
        </div>

    </footer>
</body>

</html>

<?php
extract($_POST);
if (isset($_POST["adiciona"])) {
    include_once("connect/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $descricao = $_POST["descricao"];
    $cursos = $_POST["cursos"];
    $id_perfil = $_POST['idPerfil'];

    $sql = "UPDATE Perfil SET descricao = :descricao, cursosExperiencia = :cursos WHERE id_perfil = :id_perfil";
    $queryUpdate = $resultado->prepare($sql);
    $queryUpdate->bindParam(':descricao', $descricao);
    $queryUpdate->bindParam(':cursos', $cursos);
    $queryUpdate->bindParam(':id_perfil', $id_perfil);

    if ($queryUpdate->execute()) {
        echo "<script>alert('Informações atualizadas com sucesso!');</script>";
        header("Location: perfil.php");
    } else {
        echo "<script>alert('Erro ao alterar as suas informações.');</script>";
    }
}
?>