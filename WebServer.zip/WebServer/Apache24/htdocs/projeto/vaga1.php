<?php
session_name('iniciar');
session_start();
    
if (!isset($_SESSION['id_user'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../projeto/CSSprojeto/vaga1.css">
    <title>Vaga</title>
</head>
<body>
    <header>
    <a href="pagInicial.php"><i class='bx bxs-home'></i></a>
    <div id="vaga">
    <h1>VAGA</h1>
    </div>
    </header>

   
    <div class="retangulos">
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Vaga 1" />
            <div class="n1"><h2><b>NOME DA EMPRESA</b></h2></div>
            
            <div class="n2"><p><b>VAGA 1: ...</b></p>
            <p><b>VAGA 2: ...</b></p></div>
            
            <div class="n3"><h3>CONTATO:
                <br><br>
                (46)999784523
            </h3></div>
            
        </div>
       
    <footer>
    <div class="icone2">
        <a href="cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
    </div>
    <div class="icone">
        <a href="perfil.php"><i class='bx bxs-user'></i></a>
    </div>
    </footer>
    
</body>
</html>