<?php
session_name('iniciar');
session_start();
    
if (!isset($_SESSION['id_user'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<?php
    include_once("connect/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT * FROM CursosPessoais WHERE idfk_user = ".$_SESSION['id_user'].";";
    $indice = 0;

    $executado = $resultado->prepare($sql);

    if($executado->execute())
    {
        while($linha = $executado->fetch(PDO::FETCH_ASSOC))
        {
            $linhas[$indice] = $linha;
            $indice++;
        }
    }
?>


<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/Cursos.css">
    <title>Cursos Pessoais</title>
</head>
<body>
    <header class="cabecalho">
        <a href="pagInicial.php"><i class='bx bxs-home'></i></a>
        <h1>CURSOS PESSOAIS</h1>
    </header>

        <div class="titulo">
            <h1>EM ANDAMENTO</h1>
        </div>
        <br /><br /><br /><br />      
        <div class="cards_andamento">
            
        <?php
        $indice = $indice;
        for($i = 0; $i <$indice; $i++ )
        {

            if($linhas[$i]["andamento"] == TRUE){
            print '
                <div class="cards_andamentoF"><img class="imagem" src="'.$linhas[$i]["imagem"].'" />
                    <div class="card">
                        <a href="detalhesCurso">'.$linhas[$i]["nomecursopessoal"].'</a><br />
                        '.$linhas[$i]["duracaocursopessoal"].'
                    </div>
                </div>
                ';
            }
        }
        ?>
        </div>
        <div style="clear:both;">&nbsp;</div>

        <div class="titulo_finalizados">
            <h1>FINALIZADOS</h1>
        </div>
        <div class="cards_andamento">
        <?php
        $indice = $indice;
        for($i = 0; $i <$indice; $i++ )
        {
            if($linhas[$i]["andamento"] == FALSE){
            print '
                <div class="cards_andamentoF"><img class="imagemF" src="'.$linhas[$i]["imagem"].'" />
                    <div class="card">
                        <a href="detalhesCurso">'.$linhas[$i]["nomecursopessoal"].'</a><br />
                        '.$linhas[$i]["duracaocursopessoal"].'
                    </div>
                </div>
                ';}
        }
        ?>
        </div>
        <div style="clear:both;">&nbsp;</div>
<footer>
    <div class="icons_footer">
        <a href="perfil.php"><i class='bx bxs-user-circle' ></i></a>
    </div>
</footer>
</body>
</html>

