<?php
session_name('iniciar');
session_start();
    
if (!isset($_SESSION['id_user'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="CSSprojeto/cadPerfil.css">
    <title>Informações do Perfil</title>
</head>
<body>
    <header class="header-pag">
        <a href="pagInicial.php"><button id="btn-menu"><i class='bx bxs-home' ></i></button></a>
        <h1>Cadastro de Informações</h1>
    </header>

    <div class="container">
            <div class="card_forms">
                <form action="cadastroPerfil.php" method="post" enctype="multipart/form-data">
                    <input type="text" name="descricao" id="descricao_perfil" placeholder="Adicone uma descrição sobre você" value="<??>">
                    <input type="text" name="redesSociais" id="redesSociaisPerfil" placeholder="Adicione seu email">
                    <textarea name="cursosExperiencias" id="cursosExperienciasPerfil" placeholder="Adicione seus cursos e experiencias na área"></textarea>
                    <input type="file" name="arquivo">
                    <button id="btn-add-info" name="btnAddInfo" type="submit">Adicionar Informações</button>
                </form>
            </div>
    </div>
</body>
</html>

<?php
 
    extract($_POST);
    if(isset($_POST["btnAddInfo"]))
    {
        
        $destino = 'curriculos_perfil/'.$_FILES['arquivo']['name'];
        $arquivo_tmp = $_FILES['arquivo']['tmp_name'];
        
        $extensao = pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION);
        
        if (strtolower($extensao) == 'pdf') {
            $novo_name = SHA1($_SESSION['id_user'].date('d-m-Y H:i:s')).'.pdf'; 
        
            if (move_uploaded_file($arquivo_tmp, 'curriculos_perfil/'.$novo_name)) {
                echo "Arquivo enviado com sucesso!";
            } else {
                echo "Erro ao enviar o arquivo.";
            }
        } else {
            echo "Somente arquivos PDF são permitidos.";
        }

        include_once("connect/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();
        
        $descricao = $_POST["descricao"];
        $redesSociais = $_POST["redesSociais"];
        $cursos = $_POST["cursosExperiencias"];

        $sql = "INSERT INTO Perfil (descricao, RedesSociais, cursosExperiencia, curriculo_url, user_idfk) VALUES ('".$descricao."', '".$redesSociais."', '".$cursos."', 'curriculos_perfil/".$novo_name."', ".$_SESSION["id_user"].");";
        
        $executado = $resultado->prepare($sql);
        
        if($executado->execute())
        {
            echo "<script>alert('Informações cadastradas com sucesso!');</script>";
        }
        else
        {
            echo "<srcipt>('Erro ao cadastrar as informações')</script>";
        }
    }
?>