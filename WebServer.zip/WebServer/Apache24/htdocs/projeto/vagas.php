<?php
session_name('iniciar');
session_start();
    
if (!isset($_SESSION['id_user'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../projeto/CSSprojeto/vagas.css">
    <title>Vagas</title>
</head>
<body>
    <header>
    <a href="pagInicial.php"><i class='bx bxs-home'></i></a>
    </header>

    <div id="vagas">
    <h1>VAGAS</h1>
</div>

    <div class="retangulos">
        <div class="retangulo">
           <img src="CSSprojeto/img/vaga.jpg" alt="Curso 1" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
               <a href="vaga1.php">
                     <button class="botao">SAIBA MAIS</button>
                </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 2" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-2.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 3" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-3.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 4" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-4.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 5" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-5.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 6" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-6.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 7" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-7.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 8" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-8.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 9" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-9.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/vaga.jpg" alt="Curso 10" />
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
            <a href="link-para-curso-10.html">
                <button class="botao">SAIBA MAIS</button>
            </a>
        </div>
    </div>

    <footer>
    <div class ="icone2">
        <a href="cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
    </div>
    <div class="icone">
        <a href="perfil.php"><i class='bx bxs-user'></i></a>
    </div>
    </footer>
    
</body>
</html>
