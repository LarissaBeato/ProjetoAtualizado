<?php
session_name('iniciar');
session_start();
    
if (!isset($_SESSION['id_user'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../projeto/CSSprojeto/cursos2.css">
    <title>Cursos</title>
</head>
<body>
    <header>
    <a href="pagInicial.php"><i class='bx bxs-home'></i></a>
    </header>

    <div id="cursos">
    <h1>CURSOS</h1>
    
    </div>
    <div class="retangulos">
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 1" />
            <a href="../projeto/curso1.php">Curso 1</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 2" />
            <a href="link-para-curso-2.html">Curso 2</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 3" />
            <a href="link-para-curso-3.html">Curso 3</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 4" />
            <a href="link-para-curso-4.html">Curso 4</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 5" />
            <a href="link-para-curso-5.html">Curso 5</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 6" />
            <a href="link-para-curso-6.html">Curso 6</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 7" />
            <a href="link-para-curso-7.html">Curso 7</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 8" />
            <a href="link-para-curso-8.html">Curso 8</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 9" />
            <a href="link-para-curso-9.html">Curso 9</a>
        </div>
        <div class="retangulo">
            <img src="CSSprojeto/img/curso.jpg" alt="Curso 10" />
            <a href="link-para-curso-10.html">Curso 10</a>
        </div>
    </div>
    
    <footer>
    <div class="icone2">
        <a href="cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
    </div>
    <div class="icone">
        <a href="perfil.php"><i class='bx bxs-user'></i></a>
    </div>
</footer>


    
</body>
</html>